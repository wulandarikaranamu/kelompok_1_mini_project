<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Cek Kesehatan</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="admin/assets/img/logoku.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Medilab
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-between">
      <div class="d-none d-lg-flex social-links align-items-center">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.html">Cek Kesehatan</a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#doctors">Developer</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="login.php" class="appointment-btn scrollto">Login</a>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container">
      <h1>Welcome to CEKES</h1>
      <h2>We are an experienced medical team with an innovative
      <br> approach to health care</h2>
      <a href="#registrasi" class="btn-get-started scrollto">Registrasi</a>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="row">
          <div class="col-lg-4 d-flex align-items-stretch">
            <div class="content">
              <h3>Why Choose Cekes?</h3>
              <p>
              Website cek kesehatan memberikan akses mudah ke informasi medis yang dapat membantu Anda memahami gejala, penyakit, dan perawatan kesehatan. 
              Anda dapat mengaksesnya kapan saja dan di mana saja tanpa harus menunggu janji dokter.
              </p>
              <div class="text-center">
                <a href="#" class="more-btn">Learn More <i class="bx bx-chevron-right"></i></a>
              </div>
            </div>
          </div>
          <div class="col-lg-8 d-flex align-items-stretch">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-receipt"></i>
                    <h4>Prakiraan Penyakit</h4>
                    <p>Meskipun ini hanya sebagai panduan awal, ini dapat membantu Anda memahami kemungkinan kondisi yang perlu diperiksa lebih lanjut.</p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-cube-alt"></i>
                    <h4>Kesadaran Kesehatan</h4>
                    <p>Dengan memahami risiko dan gejala penyakit tertentu, Anda dapat mengambil tindakan pencegahan yang tepat.</p>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-images"></i>
                    <h4>Konsultasi Jarak Jauh</h4>
                    <p> Ini bisa sangat bermanfaat, terutama jika Anda sulit mengakses perawatan medis secara langsung.</p>
                  </div>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container-fluid">

        <div class="row">
          <div class="col-xl-5 col-lg-6 video-box d-flex justify-content-center align-items-stretch position-relative">
            <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="glightbox play-btn mb-4"></a>
          </div>

          <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
            <h3>Kesehatan Anda Prioritas Kami Menyediakan Solusi Inovatif</h3>
            <p>Kami berkomitmen untuk memberikan solusi kesehatan yang mengutamakan kenyamanan dan keselamatan. Layanan kami didasarkan pada prinsip kepedulian dan inovasi. Kami merancang pengalaman yang bebas dari stres dan memprioritaskan kesejahteraan Anda. Kami hadir untuk membantu Anda mencapai kesehatan yang optimal dengan informasi, perawatan, dan dukungan yang sesuai.</p>

            <div class="icon-box">
              <div class="icon"><i class="fa-sharp fa-solid fa-book-medical"></i></div>
              <h4 class="title"><a href="#about">Ketegori</a></h4>
              <p class="description"> Situs web ini menyediakan informasi tentang berbagai kondisi medis, gejala, diagnosa, dan perawatan. Mereka bertujuan untuk memberikan pengetahuan medis kepada pengguna.</p>
            </div>

            <div class="icon-box">
              <div class="icon"><i class="fa-sharp fa-solid fa-stethoscope"></i></div>
              <h4 class="title"><a href="#about">Gejala</a></h4>
              <p class="description">Pengguna dapat memasukkan gejala yang mereka alami, dan situs ini memberikan informasi tentang kemungkinan penyakit atau kondisi yang mungkin mendasarinya.</p>
            </div>

            <div class="icon-box">
              <div class="icon"><i class="fa-solid fa-notes-medical"></i></div>
              <h4 class="title"><a href="#about">Penyakit</a></h4>
              <p class="description">Situs web ini dapat membantu pengguna menilai risiko mereka terhadap penyakit tertentu berdasarkan riwayat kesehatan dan gaya hidup mereka.</p>
            </div>

          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="count-box">
              <i class="fas fa-user-md"></i>
              <span data-purecounter-start="0" data-purecounter-end="85" data-purecounter-duration="1" class="purecounter"></span>
              <p>Doctors</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="count-box">
              <i class="far fa-hospital"></i>
              <span data-purecounter-start="0" data-purecounter-end="18" data-purecounter-duration="1" class="purecounter"></span>
              <p>Departments</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="fas fa-flask"></i>
              <span data-purecounter-start="0" data-purecounter-end="12" data-purecounter-duration="1" class="purecounter"></span>
              <p>Research Labs</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="fas fa-award"></i>
              <span data-purecounter-start="0" data-purecounter-end="150" data-purecounter-duration="1" class="purecounter"></span>
              <p>Awards</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Doctors Section ======= -->
    <section id="doctors" class="doctors">
      <div class="container">

        <div class="section-title">
          <h2>Developer</h2>
          <p></p>
        </div>

        <div class="row">

          <div class="col-lg-6">
            <div class="member d-flex align-items-start">
              <div class="pic"><img src="./assets/img/developer/yohan.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Yohan Dwi Bachtiar</h4>
                <span>Web Developer</span>
                <p>Universitas papua</p>
                <div class="social">
                  <!-- <a href=""><i class="ri-twitter-fill"></i></a> -->
                  <!-- <a href=""><i class="ri-facebook-fill"></i></a> -->
                  <a href="https://www.instagram.com/yohan.bachtiarr/"><i class="ri-instagram-fill"></i></a>
                  <!-- <a href=""> <i class="ri-linkedin-box-fill"></i> </a> -->
                  <a href="https://api.whatsapp.com/send?phone=6282338012337"> <i class="ri-whatsapp-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4 mt-lg-0">
            <div class="member d-flex align-items-start">
              <div class="pic"><img src="./assets/img/developer/merry.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Merry Wulansari. S</h4>
                <span>Web Developer</span>
                <p>Universitas Sulawesi Barat</p>
                <div class="social">
                  <!-- <a href=""><i class="ri-twitter-fill"></i></a> -->
                  <!-- <a href=""><i class="ri-facebook-fill"></i></a> -->
                  <a href="https://instagram.com/mryy_wlndriii?igshid=OGQ5ZDc2ODk2ZA=="><i class="ri-instagram-fill"></i></a>
                  <!-- <a href=""> <i class="ri-linkedin-box-fill"></i> </a> -->
                  <a href="https://api.whatsapp.com/send?phone=6285240591592"> <i class="ri-whatsapp-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4">
            <div class="member d-flex align-items-start">
              <div class="pic"><img src="./assets/img/developer/agus.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Agus Abdul Manan Hamas</h4>
                <span>Web Develover</span>
                <p>Universitas AMIKOM Purwokerto</p>
                <div class="social">
                  <!-- <a href=""><i class="ri-twitter-fill"></i></a> -->
                  <!-- <a href=""><i class="ri-facebook-fill"></i></a> -->
                  <a href="https://instagram.com/manan_mn17?igshid=OGQ5ZDc2ODk2ZA=="><i class="ri-instagram-fill"></i></a>
                  <!-- <a href=""> <i class="ri-linkedin-box-fill"></i> </a> -->
                  <a href="https://api.whatsapp.com/send?phone=6285228540244"> <i class="ri-whatsapp-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4">
            <div class="member d-flex align-items-start">
              <div class="pic"><img src="./assets/img/developer/try.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Try Wahyudi Saputra</h4>
                <span>Web Developer</span>
                <p>Politeknik Negeri Sriwijaya</p>
                <div class="social">
                  <!-- <a href=""><i class="ri-twitter-fill"></i></a> -->
                  <!-- <a href=""><i class="ri-facebook-fill"></i></a> -->
                  <a href="https://instagram.com/trywahyudi__?utm_source=qr&igshid=MzNlNGNkZWQ4Mg=="><i class="ri-instagram-fill"></i></a>
                  <!-- <a href=""> <i class="ri-linkedin-box-fill"></i> </a> -->
                  <a href="https://api.whatsapp.com/send?phone=6289602255585"> <i class="ri-whatsapp-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Doctors Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container">

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <!-- <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt=""> -->
                  <h3>Saul Goodman</h3>
                  <h4>Ceo &amp; Founder</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Proin iaculis purus consequat sem cure digni ssim donec porttitora entum suscipit rhoncus. Accusantium quam, ultricies eget id, aliquam eget nibh et. Maecen aliquam, risus at semper.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <!-- <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt=""> -->
                  <h3>Sara Wilsson</h3>
                  <h4>Designer</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <!-- <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt=""> -->
                  <h3>Jena Karlis</h3>
                  <h4>Store Owner</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Enim nisi quem export duis labore cillum quae magna enim sint quorum nulla quem veniam duis minim tempor labore quem eram duis noster aute amet eram fore quis sint minim.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <!-- <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt=""> -->
                  <h3>Matt Brandon</h3>
                  <h4>Freelancer</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Fugiat enim eram quae cillum dolore dolor amet nulla culpa multos export minim fugiat minim velit minim dolor enim duis veniam ipsum anim magna sunt elit fore quem dolore labore illum veniam.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <!-- <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt=""> -->
                  <h3>John Larson</h3>
                  <h4>Entrepreneur</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    Quis quorum aliqua sint quem legam fore sunt eram irure aliqua veniam tempor noster veniam enim culpa labore duis sunt culpa nulla illum cillum fugiat legam esse veniam culpa fore nisi cillum quid.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Registrasi Section ======= -->
    <section id="registrasi" class="appointment section-bg">
      <div class="container">
        <div class="row text-center">
          <div class="col">
            <h2 class="text">Registrasi</h2>
          </div>
        </div>
        <div class="row justify-content-center mb-3">
          <div class="col-md-5">
            <form class="row g-3 needs-validation" novalidate action="register_process.php" method="POST">
              <div class="col-12">
                <label for="yourName" class="form-label">Username</label>
                <input type="text" name="nama" class="form-control" placeholder="Username" id="yourName" required>
                <div class="invalid-feedback">Please enter your username.</div>
              </div>
              <div class="col-12">
                <label for="yourAge" class="form-label">Age</label>
                <input type="text" name="umur" class="form-control" placeholder="Usia anda" id="yourAge" required>
                <div class="invalid-feedback">Please enter your age.</div>
              </div>
              <div class="col-12">
                <label for="yourGender" class="form-label">Gender</label>
                <select name="jenis_kelamin" id="gender" class="form-select">
                  <option value="">Gender</option>
                  <option value="Laki-Laki">Laki-Laki</option>
                  <option value="Perempuan">Perempuan</option>
                </select>
                <div class="invalid-feedback">Please enter your Gender.</div>
              </div>
              <div class="col-12">
                <label for="yourEmail" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="Masukkan email dengan benar" id="yourEmail" required>
                <div class="invalid-feedback">Please enter a valid email address.</div>
              </div>
              <div class="col-12">
                <label for="yourPassword" class="form-label">Password</label>
                <input type="password" name="password" placeholder="Password harus terdiri dari 8-16 karakter" class="form-control" id="yourPassword" required>
                <div class="invalid-feedback">Please enter your password.</div>
              </div>
              <div class="col-12">
                <button class="btn btn-primary w-100" type="submit" value="Daftar">Register</button>
              </div>
              <div class="col-12">
                <p class="small mb-0">Already have an account? <a href="login.php">Log in</a></p>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
    <!-- End Registrasi Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Cek Kesehatan</h3>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br><br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Newsletter</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span> Kelompok 1. PT. Hendavane Indonesia
            </span></strong> Designed by Kelompok 1
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
        <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>